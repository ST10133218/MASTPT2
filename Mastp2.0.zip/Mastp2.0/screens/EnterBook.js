import {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  Button,
  StyleSheet,
} from 'react-native';


function App(){

return (
    <View>

      <View style={styles.mainPicture}>
           <Image source={require('./img/bkwm.png')} />
         </View>

          <Text style={styles.BookText}>BOOKWORM SMART</Text>

          <Text style={styles.NewText}></Text>



          <Text style={styles.nameEntry}> 
          <View style={styles.secondPicture}>
           <Image source={require('./img/search.png')} />
         </View>
       
          Search Book:</Text>


          <Text style={styles.NewText}></Text>
          

          <Text style={styles.list}>Title:</Text>
          <Text style={styles.list}>Author: </Text>
          <Text style={styles.list}>Genre: </Text>
          <Text style={styles.list}>Number of Pages:...Pages</Text>

        
          <Text style={styles.NewText}></Text>
          <Text style={styles.NewText}></Text>


          
        <Text  style={styles.WordText}>Last Book Read:
                2019 by ROD WAVE
                </Text>

          <Text style={styles.WordText}>Total Of All Books Read:
                1050 Pages
          </Text>

          <Text  style={styles.WordText}>Average Number Of Pages:
                 200 Pages
          </Text>


        

          <Text style={styles.NewText}></Text>

          <Text style={styles.NewText}></Text>

          <Text style={styles.NewText}></Text>

          <Text style={styles.NewText}></Text>

          <Text style={styles.NewText}></Text>

        
<View style={styles.menu}>
        <View style={styles.ThirdPicture}>
           <Image source={require('./img/home.png')} />
         </View>


         <Text style={styles.NewText}></Text>



         <View style={styles.ThirdPicture}>
           <Image source={require('./img/search.png')} />
         </View>

         <Text style={styles.NewText}></Text>


          <View style={styles.ThirdPicture}>
           <Image source={require('./img/return.png')} />
          </View>
          </View>


 </View>
);}

const styles = StyleSheet.create({
      BookText: {
        color: 'green',
        fontWeight: 'bold',
        fontSize: 35,
        textAlign: 'center',
        },

        mainPicture: {
            justifyContent: 'center',
            alignItems: 'left',
        },      

        secondPicture: {
            justifyContent: 'center',
            alignItems: 'center',
            width: 50,
            length: 20,
        },      

        ThirdPicture: {
          justifyContent: 'center',
          alignItems: 'left',
          margin: 20,
          padding: 15,
         },      

    
        nameEntry: {
            padding: 15,
            color: 'white',
            backgroundColor: 'orange',
            fontSize: 18,
            borderRadius: 10,
       },

       WordText: {
        color: 'black',
        fontSize: 23,
        margin: 2,
        padding: 2,
        },

        NewText: {
          color: 'black',
          fontSize: 15,
          margin: 2,
          },

menu: {
  flexDirection: 'row',
  margin: 20,
  padding: 100,
},


});
 
export default App;