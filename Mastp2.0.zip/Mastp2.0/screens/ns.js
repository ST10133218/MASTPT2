import {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  Button,
  StyleSheet,
  TouchableOpacity,
  OnPress,
} from 'react-native';

import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {Picker} from '@react-native-picker/picker';
import {AsyncStorage} from '@react-native-async-storage/async-storage';
import {launchCamera, launchImageLibrary} from 'react-native-image-picker';

import HomeScreen from './screens/HomeScreen';
import EnterBook from './screens/EnterBook';
import GenreList from './screens/GenreList';

function Screens ({ navigation }) {
  const [selectedLanguage, setSelectedLanguage] = useState();
const [text, setText] = useState('');
const [anotherVar, setAnotherVar] = useState('');
const [SearchBook, setSearchBook] = useState('');
const [textValue, setTextValue] = useState('');
const [getValue, setGetValue] = useState('');
const [count, setCount] = useState(0);
        const [dispText, setDispText] = useState('');

        const fnSaveValue = () => {
          AsyncStorage.setItem('@data',textValue);
     };
 


return(
    <View>
      <View style={styles.mainPicture}>
      
      <Image source={require('./pictures/bkwm.png')} />
      </View>
   
          <Text style={styles.BookText}>BOOKWORM SMART</Text>

          <Text style={styles.NewText}></Text>
          

          <Text style={styles.nameEntry}></Text>
    <View style={styles.secondPicture}>
           <Image source={require('./pictures/search.png')} />
           
          <TextInput
            style={styles.input}
            placeholder='Search Book:'
             onChangeText = {setTextValue}
             value = {textValue}
          />
    </View>
       
    

          <Text style={styles.WordText}>Title: When in June</Text>
          <Text style={styles.WordText}>Author: KIMBERLY JUNE</Text>
          <Text style={styles.WordText}>Genre: Autobiograpy</Text>
          <Text style={styles.WordText}>Number of Pages: 555 Pages</Text>

          <Text style={styles.NewText}></Text>

        <Text style={styles.WordText}>Last Book Read:2019 by ROD WAVE</Text>
        <Text style={styles.WordText}>Total Of All Books Read:1050 Pages</Text>
        <Text style={styles.WordText}>Average Number Of Pages:200 Pages</Text>

          <Text style={styles.NewText}></Text>
          <Text style={styles.NewText}></Text>
        


          <TouchableOpacity onPress={fnSaveValue}>
   <View style={styles.button}>
    <Text style={styles.buttonText}>SAVE INFORMATION:</Text>
   </View>
</TouchableOpacity>
 


<View style={styles.menu}>
        <View style={styles.ThirdPicture}>
           <Image source={require('./pictures/home.png')} />
         </View>


          <Text style={styles.NewText}></Text>

        <View style={styles.ThirdPicture}>
          <Image source={require('./pictures/search.png')} onPress={() => navigation.navigate('EnterBook')}/>        
        </View>

         <Text style={styles.NewText}></Text>

        <View style={styles.ThirdPicture}>
           <Image source={require('./pictures/return.png')} />
        </View>
        </View>
 </View>
);}


const styles = StyleSheet.create({
BookText: {
  color: 'green',
  fontWeight: 'bold',
  fontSize: 35,
  textAlign: 'center',
},


mainPicture: {
  justifyContent: 'center',
  alignItems: 'left',
},      


secondPicture: {
  justifyContent: 'center',
  alignItems: 'center',
  width: 50,
  length: 20,
},      


ThirdPicture: {
  justifyContent: 'center',
  alignItems: 'left',
  margin: 20,
  padding: 15,
},      


 nameEntry: {
  padding: 15,
  color: 'white',
  backgroundColor: 'orange',
  fontSize: 18,
   borderRadius: 10,
},


WordText: {
  color: 'black',
  fontSize: 23,
  margin: 2,
  padding: 2, 
},


NewText: {
  color: 'black',
  fontSize: 15,
  margin: 2,
},


menu: {
  flexDirection: 'row',
  margin: 20,
  padding: 100,
},


button: {
  alignItems: 'center',
    backgroundColor: '#DDDDDD',
    padding: 10,
},


buttonText: {
  padding: 8,
  fontSize: 18,
  
},
});
 


function HScreens({ navigation }) {
  return (
    <View style={styles.menu}>
    <View style={styles.ThirdPicture}>
       <Image source={require('./pictures/home.png')} onPress={() => navigation.navigate('HomeScreen')} />
    </View>
 
 
     <Text style={styles.NewText}></Text>
 
     <View style={styles.ThirdPicture}>
        <Image source={require('./pictures/search.png')} onPress={() => navigation.navigate('EnterBook')} />
     </View>
 
 
     <Text style={styles.NewText}></Text>
   
      <View style={styles.ThirdPicture}>
        <Image source={require('./pictures/return.png')} onPress={() => navigation.navigate('Genre')} />
      </View>
   </View>
  );
}


function EBScreen({ navigation }) {
  return (
    <View>
         <View style={styles.ThirdPicture}>
             <Image source={require('./pictures/home.png')} onPress={() => navigation.navigate('Home')} />
         </View>
    </View>
  );
}
 


function GList({ navigation }) {
  return (
    <View style={styles.menu}>
        <View style={styles.ThirdPicture}>
           <Image source={require('./pictures/home.png')} onPress={() => navigation.navigate('HomeScreen')} />
         </View>
 
 
         <Text style={styles.NewText}></Text>
 
         <View style={styles.ThirdPicture}>
           <Image source={require('./pictures/search.png')} onPress={() => navigation.navigate('EnterBook')} />
         </View>
 

           <Text style={styles.NewText}></Text>
       
          <View style={styles.ThirdPicture}>
            <Image source={require('./pictures/return.png')} onPress={() => navigation.navigate('EnterBook')} />
          </View>
    </View>
  );
}
 


const Stack = createNativeStackNavigator();
function MyStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={HomeScreen} />
      <Stack.Screen name="EnterBook" component={EnterBook} />
      <Stack.Screen name="GenreList" component={GenreList} />
    </Stack.Navigator>
  );
}


export default function App() {
  return (
    <NavigationContainer>
      <MyStack />
    </NavigationContainer>
  );
}