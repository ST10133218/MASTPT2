import React from 'react';
import {useState} from 'react';
import {
  View,
  Text,
  TextInput,
  Image,
  Button,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';


function App({ navigation }){

        const [selectedLanguage, setSelectedLanguage] = useState();
      const [text, setText] = useState('');
      const [anotherVar, setAnotherVar] = useState('');
      const [SearchBook, setSearchBook] = useState('');
      const [textValue, setTextValue] = useState('');
      const [getValue, setGetValue] = useState('');
      const [ onChangeText] = React.useState('Useless Text');
     
              const [dispText, setDispText] = useState('');
      
              const fnSaveValue = () => {
                AsyncStorage.setItem('@data',textValue);
           };












return (
    <View>

      <View style={styles.mainPicture}>
         </View>

         <Text style={styles.NewText}></Text>
         <Text style={styles.NewText}></Text>

          <Text style={styles.BookText}>BOOKWORM SMART</Text>

          <Text style={styles.NewText}></Text>



          <Text style={styles.nameEntry}> 
          <View style={styles.secondPicture}>
         </View>
       

      

          Search Book:</Text>


          <Text style={styles.NewText}></Text>
          

          <Text style={styles.WordText}>Title: When in June</Text>
          <Text style={styles.WordText}>Author: KIMBERLY JUNE</Text>
          <Text style={styles.WordText}>Genre: Autobiograpy</Text>
          <Text style={styles.WordText}>Number of Pages: 555 Pages</Text>

        
          <Text style={styles.NewText}></Text>
          <Text style={styles.NewText}></Text>


          
        <Text  style={styles.WordText}>Last Book Read:
                2019 by ROD WAVE
                </Text>

          <Text style={styles.WordText}>Total Of All Books Read:
                1050 Pages
          </Text>

          <Text  style={styles.WordText}>Average Number Of Pages:
                 200 Pages
          </Text>


        

          <Text style={styles.NewText}></Text>

          <Text style={styles.NewText}></Text>

          <Text style={styles.NewText}></Text>

          <Text style={styles.NewText}></Text>

          <Text style={styles.NewText}></Text>


          <TouchableOpacity onPress={fnSaveValue}>
   <View style={styles.button}>
    <Text style={styles.buttonText}>SAVE INFORMATION:</Text>
   </View>
</TouchableOpacity>


        
<View style={styles.menu}>
        <View style={styles.ThirdPicture}>
         </View>


          </View>


 </View>
);}

const styles = StyleSheet.create({
      BookText: {
        color: 'green',
        fontWeight: 'bold',
        fontSize: 35,
        textAlign: 'center',
        },

        mainPicture: {
            justifyContent: 'center',
            alignItems: 'left',
        },      

        secondPicture: {
            justifyContent: 'center',
            alignItems: 'center',
            width: 50,
            length: 20,
        },      

        ThirdPicture: {
          justifyContent: 'center',
          alignItems: 'left',
          margin: 20,
          padding: 15,
         },      

    
        nameEntry: {
            padding: 15,
            color: 'white',
            backgroundColor: 'orange',
            fontSize: 18,
            borderRadius: 10,
       },

       WordText: {
        color: 'black',
        fontSize: 23,
        margin: 2,
        padding: 2,
        },

        NewText: {
          color: 'black',
          fontSize: 15,
          margin: 2,
          },

menu: {
  flexDirection: 'row',
  margin: 20,
  padding: 100,
},

button: {
    bottom: 50,
    padding: 15,
    borderRadius: 16,
    borderColor: "#fff",
    borderWidth: 2,
    backgroundColor: "#CFA240",
    borderStyle: "dashed",
    elevation: 10,

  },
  
  
  buttonText: {
    padding: 8,
    fontSize: 18,
    
  },


});
 
export default App;